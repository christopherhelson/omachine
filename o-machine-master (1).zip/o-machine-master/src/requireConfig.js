requirejs.config({
    "baseUrl": "./src"
});

